IMAGES FOLDER
==============

Place all image files in this folder:

Required images:
- selections.png (album cover)
- by-every-probability.png (album cover)
- i-was-alive-enough.png (album cover)
- somethings-not-right.png (album cover)
- hero-image.jpg (homepage hero image)
- somethings-not-right-photo.png (song page photo)
- waltz-into-darkness-photo.png (song page photo)

All images referenced in the HTML files should go here.
